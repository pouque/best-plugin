#! /usr/bin/env python3

import time
import random
import socks
import socket
import re
import uuid
from threading import Thread

#Konsolechka_message_parse_raw = r":Konsolechka!konsolka@konsolech.ga PRIVMSG #s2ch :([\w\W]+)"
Konsolechka_message_parse_min = r"Хата зашкварена с \d\d.\d\d.\d\d\d\d \d\d:\d\d! Незашкваренных в хате осталось: \d+. До возможности применить команду осталось (\d+) минут"
Konsolechka_message_parse_hour = r"Хата зашкварена с \d\d.\d\d.\d\d\d\d \d\d:\d\d! Незашкваренных в хате осталось: \d+. До возможности применить команду осталось около (\d+) час"

dest = None

HOST = "chat.freenode.net"
PORT = 6667

NICK = "a%ial_twistor_%i" % (random.randint(0, 2**6), random.randint(0, 2**10))
IDENT = str(uuid.uuid4()).replace('-', '')

CHANNEL = "#s2ch"

PACKET_SIZE = 1
STANDARD_OFFSET = 3600 + 120

#proxylist = "proxylist.txt"

#ircsock = socks.socksocket()
ircsock = socket.socket()

#fil = open(proxylist, "r")
#lines = fil.readlines()
#fil.close()
#random.shuffle(lines)

#(proxy_server, proxy_port) = lines[random.randint(0, len(lines) - 1)].split(":")
#proxy_port = int(proxy_port.replace("\n", ""))

#print("Using proxy %s:%i" % (proxy_server, proxy_port))

#ircsock.setproxy(socks.PROXY_TYPE_SOCKS5, proxy_server, proxy_port)

ircsock.connect((HOST, PORT))

ircsock.send(bytes("NICK %s\r\n" % NICK, "UTF-8"))
ircsock.send(bytes("USER %s empty empty :You are gay\r\n" % IDENT, "UTF-8"))
ircsock.send(bytes("PRIVMSG NickServ :IDENTIFY BanalKarnaval fuckyougay\r\n", "UTF-8"))

error = 3

end = 0
END_EXIT = 1
END_K_LINED = 2

def condition():
    if dest != None:
        return int(dest - time.time()) in range(0, error)
    else: return False

def send_pidor():
    global dest, end
    sended = False
    while end == 0:
        current = condition()
        if current and not sended:
            dest = time.time() + STANDARD_OFFSET
            ircsock.send(bytes("PRIVMSG %s :!пидор\r\n" % CHANNEL, "UTF-8"))
            sended = True
        elif current and sended: pass
        else: sended = False
        time.sleep(1)
        pass

send_pidor_process = Thread(target=send_pidor)
send_pidor_process.start()

def endswith_nl(buff):
    try:
        s = buff.decode("utf-8")
        return s.endswith("\n") or s.endswith("\r") or s.endswith ("\r\n")
    except UnicodeDecodeError:
        return False

def recv_until_newline(s):
    data = bytes("", "UTF-8")
    while not endswith_nl(data):
        data += s.recv(PACKET_SIZE)
    return data.decode("utf-8")

while 1:
    try:
        data = recv_until_newline(ircsock)
        print(data, end='')

        if ("K-Lined" in data) and ("QUIT" in data) and (NICK in data):
            print("\nAchtung! K-Lined!")
            end = END_K_LINED
            break

        if "is now your hidden host" in data:
            ircsock.send(bytes("JOIN %s\r\n" % CHANNEL, "UTF-8"))
            ircsock.send(bytes("PRIVMSG %s :!пидор\r\n" % CHANNEL, "UTF-8"))

        splitted = data.split(" ")
        if splitted[0] == "PING":
            ircsock.send(bytes("PONG %s\r\n" % splitted[1], "UTF-8"))
        
        if not dest:
            minutes = re.search(Konsolechka_message_parse_min, data)
            hours = re.search(Konsolechka_message_parse_hour, data)
            if minutes:
                dest = time.time() + int(minutes.group(1)) * 60 + 120
            elif hours:
                dest = time.time() + int(hours.group(1)) * 3600 + 120
    except KeyboardInterrupt:
        print("\nStopped by user!")
        end = END_EXIT
        break

send_pidor_process.join()

ircsock.close()

if end != END_EXIT:
    exit(end)

# ahaha
# Хата зашкварена с 10.06.2018 17:22! Незашкваренных в хате осталось: 19. До возможности применить команду осталось 12 минут https://konsolech.ga/pidor/ - статистика и читы
# >около 1 часа


